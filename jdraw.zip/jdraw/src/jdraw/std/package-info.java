/*
 * Copyright (c) 2000-2008 Fachhochschule Nordwestschweiz (FHNW)
 * All Rights Reserved. 
 */

/**
* Contains standard implementations of framework interfaces. These standard
* implementation can/shall be replaced by better implementations.
* @author Christoph Denzler
*/
package jdraw.std;
